const express = require('express');
const morgan = require('morgan');

// inicion
var app = express();

// puerto
app.set('port', process.env.PORT || 3001);

// Middlewares
app.use(morgan('dev'));

//Variables globales
app.use((req, res, next) => {
  next();
});

//Rutas
app.use(require('./routes/esb.js'));


// Iniciar servidor
app.listen(app.get('port'), () => {
  console.log('Aplicacion en puerto: ', app.get('port'))
});
