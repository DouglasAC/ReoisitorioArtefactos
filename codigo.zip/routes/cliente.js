const express = require('express');
const router = express.Router();

// Arreglo de pedidos
var pedidos = []

// Ruta de prueba
router.get('/', (req, res) => {
  res.send(JSON.stringify({ respuesta: 'Practica 04 - 201503935' }));
});

// Mostrar todos los pedidos
router.get('/cliente/pedidos', (req, res) => {
  res.send(JSON.stringify({ pedidos: pedidos }));
});

// Generar un pedido nuevo con estado y repartidor random
router.get('/cliente/solicitar', (req, res) => {
  var menu = req.query.menu;
  var estado = Math.random() > 0.5 ? "preparando" : "enviado";
  var repartidor = Math.random() > 0.5 ? "encamino" : "entregado";
  // se crea el pedido con id random
  pedido = {
    id: Math.floor(Math.random() * 1001),
    menu: menu,
    estado: estado,
    repartidor: repartidor
  }
  pedidos.push(pedido);
  res.send(JSON.stringify({ respuesta: 'El pedido se ha realizado' }));
});

// Verificar estado del pedido
router.get('/cliente/estadoPedido', (req, res) => {
  var id = parseInt(req.query.id);
  var estado = getEstado(id);
  res.send(JSON.stringify({ estado: estado }));
});

// Verificar estado del repartido
router.get('/cliente/estadoRepartidor', (req, res) => {
  var id = parseInt(req.query.id);
  var estado = getEstadoRepartidor(id);
  res.send(JSON.stringify({ estado: estado }));
});

// Funcion para obtener el estado segun id
function getEstado(id) {
  for (var x = 0; x < pedidos.length; x++) {
    pedido = pedidos[x]
    if (pedido.id == id) {
      return pedido.estado
    }
  };
  return "No existe el pedido"
}

//Funcion para obtener el estado del repartidor seung id
function getEstadoRepartidor(id) {
  for (var x = 0; x < pedidos.length; x++) {
    pedido = pedidos[x]
    if (pedido.id == id) {
      return pedido.repartidor
    }
  };
  return "No existe el pedido"
}

module.exports = router;