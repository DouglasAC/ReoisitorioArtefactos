const express = require('express');
const morgan = require('morgan');

// inicion
var app = express();

// puerto
app.set('port', process.env.PORT || 5000);

// Middlewares
app.use(morgan('dev'));

//Variables globales
app.use((req, res, next) => {
  next();
});

//Rutas
app.use(require('./routes/cliente.js'));


// Iniciar servidor
var server = app.listen(app.get('port'), () => {
  console.log('Aplicaion en puerto: ', app.get('port'))
});


module.exports = server;