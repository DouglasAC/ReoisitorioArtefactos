const express = require('express');
const morgan = require('morgan');

// inicion
var app = express();

// puerto
app.set('port', process.env.PORT || 4000);

// Middlewares
app.use(morgan('dev'));

//Variables globales
app.use((req, res, next) => {
  next();
});

//Rutas
app.use(require('./routes/restaurante.js'));


// Iniciar servidor
app.listen(app.get('port'), () => {
  console.log('Aplicaion en puerto: ', app.get('port'))
});





