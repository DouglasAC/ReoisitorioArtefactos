const express = require('express');
const router = express.Router();

// Arreglo de pedidos
var pedidos = []

// Ruta de prueba
router.get('/', (req, res) => {
    res.send(JSON.stringify({ respuesta: 'Practica 06 - 201503935' }));
});

// Listar todos los pedidos
router.get('/repartidor/pedidos', (req, res) => {
    res.send(JSON.stringify({ pedidos: pedidos }));
  });

// Crear un pedido 
router.get('/repartidor/pedido', (req, res) => {
    var menu = req.query.menu;
    pedido = {
        id: Math.floor(Math.random() * 1001),
        menu: menu,
        estado: "Enviado"
    }
    pedidos.push(pedido);
    res.send(JSON.stringify({ respuesta: 'El pedido se ha realizado al repartidor' }));
});

// Wer estado del pedido
router.get('/repartidor/estado', (req, res) => {
    var id = parseInt(req.query.id);
    var estado = getEstado(id);
    res.send(JSON.stringify({ estado: estado }));
});

// Cambiar estado del pedido
router.get('/repartidor/entregado', (req, res) => {
    var id = parseInt(req.query.id);
    var respuesta = marcar(id);
    res.send(JSON.stringify({ Respuesta: respuesta }));
});

function getEstado(id) {
    for (var x = 0; x < pedidos.length; x++) {
        pedido = pedidos[x]
        if (pedido.id == id) {
            return pedido.estado
        }
    };
    return "No existe el pedido"
}

function marcar(id) {
    for (var x = 0; x < pedidos.length; x++) {
        pedido = pedidos[x]
        if (pedido.id == id) {
            pedido.estado = "Entregado"
        }
    };
    return "Se marco como entregado"
}
module.exports = router;