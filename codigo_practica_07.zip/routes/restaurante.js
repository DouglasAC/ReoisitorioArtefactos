const express = require('express');
const router = express.Router();

var pedidos = []

router.get('/', (req, res) => {
    res.send(JSON.stringify({ respuesta: 'Practica 06 - 201503935' }));
});

// Ver todos los pedidos
router.get('/restaurante/pedidos', (req, res) => {
    res.send(JSON.stringify({ pedidos: pedidos }));
});

// Crear un pedido
router.get('/restaurante/pedido', (req, res) => {
    var menu = req.query.menu;
    var estado = Math.random() > 0.5 ? "preparando" : "enviado";
    var repartidor = Math.random() > 0.5 ? "no esta listo" : "ya esta listo";
    pedido = {
        id: Math.floor(Math.random() * 1001),
        menu: menu,
        estado: estado,
        repartidor: repartidor
    }
    pedidos.push(pedido);
    res.send(JSON.stringify({ respuesta: 'El pedido se ha realizado' }));
});

// Ver estado del pedido
router.get('/restaurante/estadoPedido', (req, res) => {
    var id = parseInt(req.query.id);
    var estado = getEstado(id);
    res.send(JSON.stringify({ estado: estado }));
});

// Ver estado del repartidor
router.get('/restaurante/estadoRepartidor', (req, res) => {
    var id = parseInt(req.query.id);
    var estado = getEstadoRepartidor(id);
    res.send(JSON.stringify({ estado: estado }));
});

function getEstado(id) {
    for (var x = 0; x < pedidos.length; x++) {
        pedido = pedidos[x]
        if (pedido.id == id) {
            return pedido.estado
        }
    };
    return "No existe el pedido"
}

function getEstadoRepartidor(id) {
    for (var x = 0; x < pedidos.length; x++) {
        pedido = pedidos[x]
        if (pedido.id == id) {
            return pedido.repartidor
        }
    };
    return "No existe el pedido"
}


module.exports = router;