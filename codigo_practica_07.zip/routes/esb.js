const express = require('express');
const router = express.Router();
const axios = require('axios').default;


const rutaCliente = 'http://localhost:5000'
const rutaRestaurante = 'http://localhost:4000'
const rutaRepartidor = 'http://localhost:3000'

// Ruta de prueba
router.get('/', (req, res) => {
    res.send(JSON.stringify({ respuesta: 'Practica 04 - 201503935' }));
});

// Mostrar todos los pedidos de los clientes
router.get('/esb/cliente/pedidos', (req, res) => {
    enviarAlcorrecto(rutaCliente + "/cliente/pedidos", req.body, function (msg) {
        res.send(msg)
    });
});

// Generar pedido cliente
router.get('/esb/cliente/solicitar', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaCliente + "/cliente/solicitar?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Verificar estado del pedido
router.get('/esb/cliente/estadoPedido', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaCliente + "/cliente/estadoPedido?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Verificar estado del repartido Cliente
router.get('/esb/cliente/estadoRepartidor', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaCliente + "/cliente/estadoRepartidor?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

////////////////////////////// Resataurante 
// Ver todos los pedidos
router.get('/esb/restaurante/pedidos', (req, res) => {
    enviarAlcorrecto(rutaRestaurante + "/restaurante/pedidos", req.body, function (msg) {
        res.send(msg)
    });
});

// Crear un pedido
router.get('/esb/restaurante/pedido', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRestaurante + "/restaurante/pedido?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Ver estado del pedido
router.get('/esb/restaurante/estadoPedido', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRestaurante + "/restaurante/estadoPedido?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Ver estado del repartidor
router.get('/esb/restaurante/estadoRepartidor', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRestaurante + "/restaurante/estadoRepartidor?" + params, req.body, function (msg) {
        res.send(msg)
    });
});


//////////////////// Repartidor //////////////////////////

// Listar todos los pedidos
router.get('/esb/repartidor/pedidos', (req, res) => {
    enviarAlcorrecto(rutaRepartidor + "/repartidor/pedidos", req.body, function (msg) {
        res.send(msg)
    });
});

// Crear un pedido 
router.get('/esb/repartidor/pedido', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRepartidor + "/repartidor/pedido?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Ver estado del pedido
router.get('/esb/repartidor/estado', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRepartidor + "/repartidor/estado?" + params, req.body, function (msg) {
        res.send(msg)
    });
});

// Cambiar estado del pedido
router.get('/esb/repartidor/entregado', (req, res) => {
    const params = new URLSearchParams(req.query).toString();
    enviarAlcorrecto(rutaRepartidor + "/repartidor/entregado?" + params, req.body, function (msg) {
        res.send(msg)
    });
});


// Enviar a la ruta correcta
function enviarAlcorrecto(url, datos, callback) {
    // Solicitar Pedido
    let parametros = {
        method: 'get',
        url: url,
        data: datos,
        headers: {
            'Content-Type': 'application/json'
        }
    }

    axios(parametros)
        .then(function (response) {
            callback(response.data)
        })
        .catch(function (error) {
            console.error(error)
        });
}

module.exports = router;